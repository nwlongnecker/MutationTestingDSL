package src;

public class LogicalFunctions {

	public static boolean logicalAnd(boolean one, boolean two) {
		return one && two;
	}
	
	public static boolean logicalOr(boolean one, boolean two) {
		return one || two;
	}
}
