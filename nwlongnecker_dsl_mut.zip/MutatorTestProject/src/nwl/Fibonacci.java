package nwl;

public class Fibonacci {
	
	int current;
	int last;
	
	public Fibonacci() {
		current = 1;
		last = 0;
	}

	public int getNextNumber() {
		int next = current + last;
		last = current;
		current = next;
		return current;
	}
	
	public static int getNumAt(int index) {
		if (index == 1 || index == 2) {
			return 1;
		}
		return getNumAt(index - 2) + getNumAt(index - 1);
	}
}
