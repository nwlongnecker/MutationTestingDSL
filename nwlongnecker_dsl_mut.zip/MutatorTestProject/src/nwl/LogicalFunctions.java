package nwl;

public class LogicalFunctions {

	public static boolean logicalAnd(boolean one, boolean two) {
		return one && two;
	}
	
	public static boolean logicalOr(boolean one, boolean two) {
		return one || two;
	}
	
	public static boolean andThenOr(boolean one, boolean two, boolean three) {
		return one && two || three;
	}
}
