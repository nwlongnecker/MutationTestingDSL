package nwl;

public class MathFunctions {

	public static int add(int one, int two) {
		return one + two;
	}
	
	public static int subtract(int one, int two) {
		return one - two;
	}
	
	public static int multiply(int one, int two) {
		return one * two;
	}
	
	public static int divide(int one, int two) {
		return one / two;
	}
	
	public static int addThenSubtract(int one, int two, int three) {
		return one + two - three;
	}
}
