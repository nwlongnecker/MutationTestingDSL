package nwl;

public class MathParser {

	public static int parse(String input) {
		int indexOfPlus = input.lastIndexOf("+");
		int indexOfMinus = input.lastIndexOf("-");
		
		if (indexOfPlus > indexOfMinus) {
			return MathFunctions.add(parse(input.substring(0, indexOfPlus)), parse(input.substring(indexOfPlus + 1)));
		} else if (indexOfMinus >= 0) {
			return MathFunctions.subtract(parse(input.substring(0, indexOfMinus)), parse(input.substring(indexOfMinus + 1)));
		}
		
		int indexOfMult = input.lastIndexOf("*");
		int indexOfDiv = input.lastIndexOf("/");
		
		if (indexOfMult > indexOfDiv) {
			return MathFunctions.multiply(parse(input.substring(0, indexOfMult)), parse(input.substring(indexOfMult + 1)));
		} else if (indexOfDiv >= 0) {
			return MathFunctions.divide(parse(input.substring(0, indexOfDiv)), parse(input.substring(indexOfDiv + 1)));
		}
		
		return Integer.parseInt(input);
	}
}
