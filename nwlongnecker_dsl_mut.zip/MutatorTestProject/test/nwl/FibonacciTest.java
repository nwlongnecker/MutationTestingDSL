package nwl;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FibonacciTest {

	@Test
	public void getFirst() {
		Fibonacci f = new Fibonacci();
		assertEquals(1, f.getNextNumber());
	}

	@Test
	public void getFirstFive() {
		Fibonacci f = new Fibonacci();
		assertEquals(1, f.getNextNumber());
		assertEquals(2, f.getNextNumber());
		assertEquals(3, f.getNextNumber());
		assertEquals(5, f.getNextNumber());
		assertEquals(8, f.getNextNumber());
	}

	@Test
	public void getNumAtTen() {
		assertEquals(55, Fibonacci.getNumAt(10));
	}

	@Test
	public void getNumAtTwenty() {
		assertEquals(6765, Fibonacci.getNumAt(20));
	}
}
