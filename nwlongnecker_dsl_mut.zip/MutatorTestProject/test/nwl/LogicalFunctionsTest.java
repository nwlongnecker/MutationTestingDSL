package nwl;

import static org.junit.Assert.*;
import nwl.LogicalFunctions;

import org.junit.Test;

public class LogicalFunctionsTest {

	@Test
	public void testAnd() {
		assertFalse(LogicalFunctions.logicalAnd(false, true));
	}
	
	@Test
	public void testOr() {
		assertTrue(LogicalFunctions.logicalOr(false, true));
	}
	
	@Test
	public void testAndThenOr() {
		assertFalse(LogicalFunctions.andThenOr(false, false, false));
	}
	
	@Test
	public void testAndThenOr2() {
		assertFalse(LogicalFunctions.andThenOr(false, true, false));
	}
	
	@Test
	public void testAndThenOr3() {
		assertTrue(LogicalFunctions.andThenOr(false, true, true));
	}
}
