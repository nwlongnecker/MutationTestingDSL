package nwl;

import static org.junit.Assert.*;

import org.junit.Test;

public class MathParserTest {

	@Test
	public void onePlusOne() {
		assertEquals(2, MathParser.parse("1+1"));
	}

	@Test
	public void TwoMinusOne() {
		assertEquals(1, MathParser.parse("2-1"));
	}

	@Test
	public void TwoTimesTwo() {
		assertEquals(4, MathParser.parse("2*2"));
	}

	@Test
	public void FourDivTwo() {
		assertEquals(2, MathParser.parse("4/2"));
	}

	@Test
	public void MultThenAdd() {
		assertEquals(17, MathParser.parse("5*3+2"));
	}

	@Test
	public void MixedOperations() {
		assertEquals(19, MathParser.parse("5*3+8/4*3-2"));
	}

	@Test
	public void AddAndSubtract() {
		assertEquals(-6, MathParser.parse("5-6+2-7"));
	}
}
